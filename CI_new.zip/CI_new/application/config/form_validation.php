<?php

$config=[

    'add_articles_rules'=>[

                    [
                        'field'=>'article_title',
                        'label'=>'Article Title',
                        'rules'=>'required|alpha'
                    ],
                    [
                        'field'=>'article_desc',
                        'label'=>'Article Description',
                        'rules'=>'required'
                    ] 
    ]




    
];










?>
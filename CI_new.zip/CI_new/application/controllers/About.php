<?php

class About extends My_Controller {
    
	public function index()
	{
		$this->load->view('about');
	}
}

?>
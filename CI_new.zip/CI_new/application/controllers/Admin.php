<?php 


class Admin extends CI_Controller  {


	public function register(){
		
		$this->form_validation->set_rules('uname', 'Username', 'required|alpha|max_length[10]');
		$this->form_validation->set_rules('pass', 'Password', 'required|max_length[15]');
		$this->form_validation->set_rules('firstname', 'First Name', 'required|alpha|max_length[15]');
		$this->form_validation->set_rules('lastname', 'Last Name', 'required|max_length[15]');
		$this->form_validation->set_rules('email', 'email', 'required');
		
		$this->form_validation->set_error_delimiters('<div class="error text-danger">', '</div>');

		if ($this->form_validation->run() == FALSE)
		{
				$this->load->view('Admin/register');
		}
		else
		{
				$post=$this->input->post();
				
				$this->load->model('loginModel');
				
				$result=$this->loginModel->add_user($post);
				
				if($result){
					$this->session->set_flashdata('register success','Your registration is done successfully! Now you can Login');
					return redirect('Admin/adduser');
					
				}else{
					$this->session->set_flashdata('register fail','Your registration is not done successfully!Please correct the errors');
					$this->load->view('Admin/adduser');
				}
		}
		
	}
	public function login(){
		$this->form_validation->set_rules('uname', 'Username', 
		'required|alpha|max_length[10]',
		array('required' => '*The %s Field is required.', 'is_unique'=> 'This %s already exists.'));
		
		$this->form_validation->set_rules('pass', 'Password', 
		'required|max_length[15]',
		array('required' => '* The %s Field is required.', 'is_unique'=> 'This %s already exists.'));
		
		$this->form_validation->set_error_delimiters('<div class="error text-danger">', '</div>');

		if ($this->form_validation->run() == FALSE)
		{
				$this->load->view('Admin/Login');
		}
		else
		{
				$uname= $this->input->post('uname');
				$pass= $this->input->post('pass');
				$this->load->model('loginModel');
				
				$login_id=$this->loginModel->isvalidate($uname,$pass);
				
				if($login_id){
					$this->session->set_userdata('id',$login_id);
					$this->session->set_flashdata('login success','Welcome<?=$uname?>to the dashboard');
return redirect('Admin/welcome');

}else{
$this->session->set_flashdata('login failed','Invalid Username/Password');
$this->load->view('Admin/Login');
}
}
}

public function logout(){
$this->session->unset_userdata('id');
$this->session->set_flashdata('logout success','you have been successfully logged out! Please login to continue again');
return redirect('login');;

}

public function welcome(){
if(!($this->session->userdata('id'))){
return redirect('login');
}
else{
$this->load->model('loginModel');
$articles=$this->loginModel->showarticlelist();
$this->load->view('Admin/dashboard',['articles'=>$articles]);

}
}


public function addarticle(){

if ($this->form_validation->run('add_articles_rules'))
{
$post=$this->input->post();
$this->load->model('loginModel');
$articles=$this->loginModel->add_article($post);
if($articles){
$this->session->set_flashdata('insert_msg','Article is inserted successfully');
$this->session->set_flashdata('insert_class','alert-success');

}else{
$this->session->set_flashdata('insert_msg','Article is not inserted successfully');
$this->session->set_flashdata('insert_class','alert-danger');

}

return redirect ('Admin/welcome');
}
else{
$this->load->view('Admin/add_article');
}

}


public function adduser(){
$this->load->view('Admin/register');
}



public function editarticle(){
$this->load->view('Admin/edit_article');
}



public function delarticle(){
$id=$this->input->post('id');
$this->load->model('loginmodel');
$result=$this->loginmodel->del_article($id);
if($result){
$this->session->set_flashdata('del_msg','Article is Deleted successfully');
$this->session->set_flashdata('del_class','alert-success');
}else{
$this->session->set_flashdata('del_msg','Article is not Deleted successfully');
$this->session->set_flashdata('del_class','alert-danger');
}
return redirect('Admin/welcome');
}
}
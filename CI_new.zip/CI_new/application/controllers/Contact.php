<?php

class Contact extends CI_Controller  {
    
	public function index()
	{
		$this->load->view('contact');
	}
	public function addcontact(){
		
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('phone', 'Phone Number', 'required');
		$this->form_validation->set_rules('message', 'Message', 'required');
		
		$this->form_validation->set_error_delimiters('<div class="error text-danger">', '</div>');

		if ($this->form_validation->run() == FALSE)
		{
			return redirect('contact');
		}
		else
		{
				$post=$this->input->post();
				
				$this->load->model('contactModel');
				
				$result=$this->contactModel->add_contact($post);
				
				if($result){
					$this->session->set_flashdata('contact_msg','Your Message is sent successfully!');
					$this->session->set_flashdata('contact_class','alert-success');
					return redirect('contact');
					
				}else{
					
					$this->session->set_flashdata('contact_msg','Your Message is not sent successfully! Please Try Again');
					$this->session->set_flashdata('contact_class','alert-success');
					return redirect('contact');
					
				}
		}
	}
	
}

?>
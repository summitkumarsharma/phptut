<?php

class Features extends CI_Controller {
    
	public function index()
	{
		$this->load->view('features');
	}
}

?>
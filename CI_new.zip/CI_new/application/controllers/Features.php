<?php

class Features extends My_Controller {
    
	public function index()
	{
		$this->load->view('features');
	}
}

?>
<?php

class Home extends CI_Controller  {
    
	public function index()
	{
		$this->load->view('home');
	}
	public function about()
	{
		$this->load->view('about');
	}
	public function how()
	{
		$this->load->view('how');
	}
	public function pricing()
	{
		$this->load->view('pricing');
	}	
	public function contact()
	{
		$this->load->view('contact');
	}
	public function features()
	{
		$this->load->view('features');
	}
	public function examples()
	{
		$this->load->view('examples');
	}
}

?>
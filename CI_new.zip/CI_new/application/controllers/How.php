<?php

class How extends My_Controller {
    
	public function index()
	{
		$this->load->view('how');
	}
}

?>
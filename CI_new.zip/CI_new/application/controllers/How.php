<?php

class How extends CI_Controller  {
    
	public function index()
	{
		$this->load->view('how');
	}
}

?>
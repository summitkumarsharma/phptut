<?php

class Pricing extends My_Controller {
    
	public function index()
	{
		$this->load->view('pricing');
	}
}

?>
<?php 


class Users extends CI_Controller  {

	public function index()
	{
		$this->load->model('loginModel');
		$articles=$this->loginModel->showblogarticlelist();
		$this->load->view('Users/articleList',['articles'=>$articles]);
	}
	
}

?>
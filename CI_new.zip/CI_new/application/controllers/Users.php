<?php 


class Users extends My_Controller {

	public function index()
	{
		$this->load->model('loginModel');
		$articles=$this->loginModel->showblogarticlelist();
		$this->load->view('Users/articleList',['articles'=>$articles]);
	}
	
}

?>
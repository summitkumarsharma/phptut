<?php 


class login extends My_Controller {

    public function index()
	{
		
		$this->form_validation->set_rules('uname', 'Username', 
		'required|alpha|max_length[10]',
		array('required' => '*The %s Field is required.', 'is_unique'=> 'This %s already exists.'));
		
		$this->form_validation->set_rules('pass', 'Password', 
		'required|max_length[15]',
		array('required' => '* The %s Field is required.', 'is_unique'=> 'This %s already exists.'));
		
		$this->form_validation->set_error_delimiters('<div class="error text-danger">', '</div>');

		if ($this->form_validation->run() == FALSE)
		{
				$this->load->view('Admin/Login');
		}
		else
		{
				$uname= $this->input->post('uname');
				$pass= $this->input->post('pass');
				$this->load->model('loginModel');
				
				$login_id=$this->loginModel->isvalidate($uname,$pass);
				
				if($login_id){
					$this->session->set_userdata('id',$login_id);
					$this->session->set_flashdata('login success','Welcome <?=$uname?> to the dashboard');
return redirect('Admin/welcome');

}else{
$this->session->set_flashdata('login failed','Invalid Username/Password');
$this->load->view('Admin/Login');
}
}

}


}

?>
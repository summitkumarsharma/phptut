<?php 


class My_Controller extends CI_Controller {

	public function index()
	{
		echo"Hello Welcome page";
	}

}

?>
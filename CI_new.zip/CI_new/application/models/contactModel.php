<?php

class contactModel extends CI_Model{
    
     public function add_contact($array){
      
        return $this->db->insert('contact',$array);
       
     
     }
}
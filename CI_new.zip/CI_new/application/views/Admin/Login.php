<?php include "header.php"?>

<div class="container my-4">

    <div class="jumbotron jumbotron-fluid text-center">
        <div class="container">
            <h1 class="display-4 animate__animated animate__backInLeft">Welcome to Admin Login Panel</h1>
            <p class="lead animate__animated animate__backInDown">Login to Create, Edit and Modify Blog Article here....
            </p>
        </div>
    </div>

    <?php if($error = $this->session->flashdata('login failed')): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Error!</strong>
        <?php echo $error; ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif;?>

    <?php if($success = $this->session->flashdata('logout success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong>
        <?php echo $success; ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif;?>

    <h2 class="animate__animated animate__zoomIn">Login Here</h2>

    <div class="container my-4 shadow-lg p-3 mb-5 bg-light rounded animate__animated animate__slideInUp">
        <?php echo form_open('login');?>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="Username">Username:</label>
                <?php echo form_input(['class'=>'form-control','id'=>'email','name'=>'uname','placeholder'=>'Enter Username','value'=>set_value('uname')]);?>
            </div>
            <div class="form-group col-md-6" style="margin-top:40px">
                <?php echo form_error('uname'); ?>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="Password">Password:</label>
                <?php echo form_password(['class'=>'form-control','id'=>'pass','name'=>'pass','placeholder'=>'Enter Password','value'=>set_value('pass')]);?>
            </div>
            <div class="form-group col-md-6" style="margin-top:40px">
                <?php echo form_error('pass'); ?>
            </div>
        </div>
        <?php echo form_submit(['class'=>'btn btn-primary','type'=>'submit','value'=>'Submit']);?>
        <?php echo form_reset(['class'=>'btn btn-primary','type'=>'reset','value'=>'Reset']);?>
        <?php echo anchor('Admin/register', 'Sign up!','class="btn btn-success"');?>
    </div>
</div>


<?php include "footer.php"?>
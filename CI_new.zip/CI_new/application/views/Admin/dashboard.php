<?php include "header.php"?>


<div class="container px-0 py-0 my-4 text-center wow slideInRight">
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-4">Welcome to Admin Panel Dashboard </h1>
            <p class="lead">Create, Edit and Modify Blog Articles Here....</p>
        </div>
    </div>
</div>

<?php if($success = $this->session->flashdata('login success')): ?>
<div class="alert alert-success alert-dismissible fade show text-center" role="alert">
    <?php echo $success; ?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif;?>


<!-- <?php print_r($articles);?> -->

<div class="container">
    <?php if($insert_msg = $this->session->flashdata('insert_msg')):$insert_class=$this->session->flashdata('insert_class') ?>
    <div class="alert <?=$insert_class?> alert-dismissible fade show" role="alert">
        <?= $insert_msg ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif;?>

    <?php if($del_msg = $this->session->flashdata('del_msg')):$del_class=$this->session->flashdata('del_class') ?>
    <div class="alert <?=$del_class?> alert-dismissible fade show" role="alert">
        <?= $del_msg ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif;?>
    <div class="row py-2 px-4">
        <a href="addarticle" class="btn btn-primary">Add Articles</a>
    </div>

    <table class="table table-bordered table-dark">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Article Title</th>
                <th scope="col">Article Description</th>
                <th scope="col">TimeStamp</th>
                <th scope="col">Edit Action</th>
                <th scope="col">Delete Action</th>
            </tr>
        </thead>
        <tbody>

            <?php if(count($articles)):?>
            <?php  foreach($articles as $art ): ?>
            <tr>
                <th scope="row"><?php echo $art->id;?></th>
                <td>
                    <?php echo $art->article_title;?>
                </td>
                <td>
                    <?php echo substr($art->article_desc,0,50);?>
                </td>
                <td>
                    <?php echo $art->tstamp;?>
                </td>
                <td>
                    <a href="editarticle" class='btn bt-sm btn-primary'>Edit</a>
                </td>
                <td>
                    <?=
                    form_open('Admin/delarticle'),
                    form_hidden('id',$art->id),
                    form_submit(['class'=>'btn bt-sm btn-danger ml-2','type'=>'submit','value'=>'Delete']);
                    form_close();
                    ?>
                </td>
            </tr>
            <?php endforeach; ?>

            <?php else: ?>
            <tr>
                <td colspan=" 3">No Data Avaiable....</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>


</div>

<?php include "footer.php"?>
<?php include "header.php"?>

<div class="container my-4">

    <div class="jumbotron jumbotron-fluid text-center">
        <div class="container">
            <h1 class="display-4">Welcome to Admin Login Panel</h1>
            <p class="lead">Login to Create, Edit and Modify Blog Article here....</p>
        </div>
    </div>


    <h3>Edit Articles</h3>


    <?php echo form_open('Admin/editarticle');?>
    <?php echo form_hidden('user_id',($this->session->userdata('id')));?>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="article_title"> Edit Article Title:</label>
            <?php echo form_input(['class'=>'form-control','id'=>'article_title','name'=>'article_title','placeholder'=>'Enter Article Title','value'=>set_value('article_title')]);?>
        </div>
        <div class="form-group col-md-6" style="margin-top:40px; color:red">
            <?php echo form_error('article_title'); ?>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="article_desc">Edit Article Description:</label>
            <?php echo form_textarea(['class'=>'form-control','id'=>'article_desc','name'=>'article_desc','placeholder'=>'Enter Article Description','value'=>set_value('article_desc')]);?>
        </div>
        <div class="form-group col-md-6" style="margin-top:40px;color:red">
            <?php echo form_error('article_desc'); ?>
        </div>
    </div>
    <?php echo form_submit(['class'=>'btn btn-primary','type'=>'submit','value'=>'Submit']);?>
    <?php echo form_reset(['class'=>'btn btn-primary','type'=>'reset','value'=>'Reset']);?>

</div>


<?php include "footer.php"?>
<?php 
$d = date("Y-m-d H:i:s");
$year = date("Y");
?>
<footer class="footer fixed-bottom mt-auto py-2 bg-dark">
    <div class="container text-center">
        <span class="text-center text-light">Copyright@ <?php echo $year ?> iCoder Coding Blog || All
            rights reserved. Last updated on <?php echo $d ?></span>

    </div>
</footer>
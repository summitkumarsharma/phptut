<?php include "header.php"?>

<div class="container my-4">
    <div class="jumbotron jumbotron-fluid text-center">
        <div class="container">
            <h1 class="display-4">Welcome to Registartion Panel</h1>
            <p class="lead">Create an Account Here....</p>
        </div>
    </div>
    <?php if($success = $this->session->flashdata('register success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong>
        <?php echo $success; ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif;?>

    <h3>Registration Form</h3>
    <!-- <?php echo validation_errors(); ?> -->
    <?php echo form_open('Admin/register');?>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="Username">Username:</label>
            <?php echo form_input(['class'=>'form-control','id'=>'email','name'=>'uname','placeholder'=>'Enter Username','value'=>set_value('uname')]);?>
        </div>
        <div class="form-group col-md-6" style="margin-top:40px">
            <?php echo form_error('uname'); ?>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="Password">Password:</label>
            <?php echo form_password(['class'=>'form-control','id'=>'pass','name'=>'pass','placeholder'=>'Enter Password','value'=>set_value('pass')]);?>
        </div>
        <div class="form-group col-md-6" style="margin-top:40px">
            <?php echo form_error('pass'); ?>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="fname">First Name:</label>
            <?php echo form_input(['class'=>'form-control','id'=>'firstname','name'=>'firstname','placeholder'=>'Enter First Name','value'=>set_value('firstname')]);?>
        </div>
        <div class="form-group col-md-6" style="margin-top:40px">
            <?php echo form_error('firstname'); ?>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="lastname">Last Name:</label>
            <?php echo form_input(['class'=>'form-control','id'=>'lastname','name'=>'lastname','placeholder'=>'Enter Last Name','value'=>set_value('lastname')]);?>
        </div>
        <div class="form-group col-md-6" style="margin-top:40px">
            <?php echo form_error('lastname'); ?>
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="fname">Email:</label>
            <?php echo form_input(['class'=>'form-control','id'=>'email','name'=>'email','placeholder'=>'Enter Email','value'=>set_value('email')]);?>
        </div>
        <div class="form-group col-md-6" style="margin-top:40px">
            <?php echo form_error('email'); ?>
        </div>
    </div>
    <?php echo form_submit(['class'=>'btn btn-primary','type'=>'submit','value'=>'Submit']);?>
    <?php echo form_reset(['class'=>'btn btn-primary','type'=>'reset','value'=>'Reset']);?>

</div>


<?php include "footer.php"?>
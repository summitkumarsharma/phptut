<div class="inner">
    <div class="ttl-block">
        <h1>Your Dibiz should look just as good as you.</h1>
        <!-- <div class="text-small"></div> -->
    </div>


    <div class="mdl-grid">
        <div id="fb-card" class="mdl-cell mdl-cell--8-col gray-card">
            <h5>To make this even easier, we can pull your Facebook Page or Profile images. To do so, We need you to
                link your Facebook account with Dibiz.</h5>
            <div class="action-wrapper">
                <div class="actions">
                    <a class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored mdl-button-large"
                        href="/users/auth/facebook" data-upgraded=",MaterialButton">
                        <span id="fb-ico"><img src="/assets/registration/fb-ico.png" alt="Facebook" width="34"
                                height="34"></span>Let's do it. Log in with facebook
                    </a> </div>
                <div class="text-small">In the next step you need to give facebook permission to provide us some basic
                    profile information.</div>
            </div>
        </div>

        <div class="mdl-cell mdl-cell--4-col gray-card">
            <h5>Don't Have Facebook?<br>No Worries</h5>
            <div class="action-wrapper">
                <div class="actions">

                    <a class="mdl-button mdl-js-button mdl-button--raised mdl-button-large mdl-dark-gray"
                        href="/en/select-design" data-upgraded=",MaterialButton">Continue without facebook</a>
                </div>
                <div class="text-small">Next, you will be asked to provide a featured image for your Dibiz.</div>
            </div>
        </div>
    </div>

    <!-- <div class="text-small go-back">
			</div> -->
</div>
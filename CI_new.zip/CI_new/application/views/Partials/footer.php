<?php 
$d = date("Y-m-d H:i:s");
$year = date("Y");
?>
<footer class="footer mt-auto py-4 bg-dark">
    <div class="container align-items-center justify-content-center text-center">
        <div class="row align-items-center justify-content-center text-center">
            <div class="col-lg-8 col-md-8 mx-auto">
                <ul class="list-inline text-center">
                    <li class="list-inline-item">
                        <a href="#">
                            <span class="fa-stack fa-lg">
                                <i class="fa fa-square-o fa-stack-2x"></i>
                                <i class="fa fa-twitter fa-stack-1x"></i>
                            </span>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#">
                            <span class="fa-stack fa-lg">
                                <i class="fa fa-square-o fa-stack-2x"></i>
                                <i class="fa fa-facebook fa-stack-1x"></i>
                            </span>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#">
                            <span class="fa-stack fa-lg">
                                <i class="fa fa-square-o fa-stack-2x"></i>
                                <i class="fa fa-instagram fa-stack-1x"></i>
                            </span>
                        </a>
                    </li>
                </ul>
                <p class=""> Copyright@ <?php echo $year ?>
                    ONLINE DIGITAL VISITING CARD || All rights reserved.Last updated on <?php echo $d ?>
                </p>
            </div>
            <div class="col-lg-4 col-md-4 mx-auto">
                <p class="float-right">
                    <a href="#"><i class="fa fa-angle-double-up" aria-hidden="true"></i>&nbsp;Back to top</a>
                </p>
            </div>
        </div>
    </div>
</footer>
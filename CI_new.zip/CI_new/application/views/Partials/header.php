<?php

echo'
<header class="sticky-top">
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <a class="navbar-brand" href="#">Online Digital Visiting Card</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto text-capitalize">
                    <li class="nav-item active">
                        <a class="nav-link" href="home"><i class="fa fa-home fa-fw"
                                aria-hidden="true"></i>&nbsp;Home<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about"><i class="fa fa-handshake-o" aria-hidden="true"></i>&nbsp;About
                            Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pricing"><i class="fa fa-credit-card" aria-hidden="true"></i>&nbsp;Our
                            Pricing</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="how">How it works<i class="fa fa-question-circle"
                                aria-hidden="true"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="features"><i class="fa fa-hand-o-up"
                                aria-hidden="true"></i>&nbsp;Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="examples"><i class="fa fa-product-hunt"
                                aria-hidden="true"></i>&nbsp;Examples</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact"><i class="fa fa-address-card-o"
                                aria-hidden="true"></i>&nbsp;Contact Us</a>
                    </li>
                </ul>
                <button class="btn btn-success rounded-pill my-2 my-sm-0 mr-2" data-toggle="modal" data-target="#loginModal" type="
                    button">Login</button>
                <button class="btn btn-success rounded-pill my-2 my-sm-0" type="submit">Sign Up For Free</button>
            </div>
        </nav>
    </header>';
    include'loginModal.php';
?>
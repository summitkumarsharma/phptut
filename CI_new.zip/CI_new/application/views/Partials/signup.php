<!doctype html>
<html lang="en">

<head>
    <title>Signup- Digital Visiting Card</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link rel="stylesheet" href="<?= base_url()?>Assets/css/style.css">
    <style>
    #signup-step {
        /* margin: auto; */
        padding: 0;
        width: 53%;
    }

    #signup-step li {
        list-style: none;
        float: left;
        padding: 5px 10px;
        border-top: #004C9C 1px solid;
        border-left: #004C9C 1px solid;
        border-right: #004C9C 1px solid;
        border-radius: 5px 5px 0 0;
    }

    .active {
        color: #FFF;
    }

    #signup-step li.active {
        background-color: #004C9C;
    }

    #signup-form {
        clear: both;
        border: 1px #004C9C solid;
        padding: 20px;
        width: 100%;
        margin: auto;
    }

    .demoInputBox {
        padding: 10px;
        border: #CDCDCD 1px solid;
        border-radius: 4px;
        background-color: #FFF;
        width: 50%;
    }

    .signup-error {
        color: #FF0000;
        padding-left: 15px;
    }

    .message {
        color: #00FF00;
        font-weight: bold;
        width: 100%;
        padding: 10;
    }

    .btnAction {
        padding: 5px 10px;
        background-color: #F00;
        border: 0;
        color: #FFF;
        cursor: pointer;
        margin-top: 15px;
    }

    label {
        line-height: 35px;
    }
    </style>

    <script>
    function validate() {
        var output = true;
        $(".signup-error").html('');

        if ($("#personal-field").css('display') != 'none') {
            if (!($("#fname").val())) {
                output = false;
                $("#fname-error").html("Name required!");
            }
            if (!($("#lname").val())) {
                output = false;
                $("#lname-error").html("Name required!");
            }
            if (!($("#phone").val())) {
                output = false;
                $("#phone-error").html("Name required!");
            }
            if (!$("#email").val().match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/)) {
                $("#email-error").html("Invalid Email!");
                output = false;
            }
            if (!($("#password").val())) {
                output = false;
                $("#password-error").html("Password required!");
            }
        }

        if ($("#password-field").css('display') != 'none') {
            if (!($("#user-password").val())) {
                output = false;
                $("#password-error").html("Password required!");
            }

            if (!($("#confirm-password").val())) {
                output = false;
                $("#confirm-password-error").html("Confirm password required!");
            }

            if ($("#user-password").val() != $("#confirm-password").val()) {
                output = false;
                $("#confirm-password-error").html("Password not matched!");
            }
        }

        if ($("#contact-field").css('display') != 'none') {
            if (!($("#phone").val())) {
                output = false;
                $("#phone-error").html("Phone required!");
            }

            if (!($("#email").val())) {
                output = false;
                $("#email-error").html("Email required!");
            }

            if (!$("#email").val().match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/)) {
                $("#email-error").html("Invalid Email!");
                output = false;
            }

            if (!($("#address").val())) {
                output = false;
                $("#address-error").html("Address required!");
            }
        }

        return output;
    }

    $(document).ready(function() {
        $("#next").click(function() {
            var output = validate();
            if (output === true) {
                var current = $(".active");
                var next = $(".active").next("li");
                if (next.length > 0) {
                    $("#" + current.attr("id") + "-field").hide();
                    $("#" + next.attr("id") + "-field").show();
                    $("#back").show();
                    $("#finish").hide();
                    $(".active").removeClass("active");
                    next.addClass("active");
                    if ($(".active").attr("id") == $("li").last().attr("id")) {
                        $("#next").hide();
                        $("#finish").show();
                    }
                }
            }
        });


        $("#back").click(function() {
            var current = $(".active");
            var prev = $(".active").prev("li");
            if (prev.length > 0) {
                $("#" + current.attr("id") + "-field").hide();
                $("#" + prev.attr("id") + "-field").show();
                $("#next").show();
                $("#finish").hide();
                $(".active").removeClass("active");
                prev.addClass("active");
                if ($(".active").attr("id") == $("li").first().attr("id")) {
                    $("#back").hide();
                }
            }
        });

        $("input#finish").click(function(e) {
            var output = validate();
            var current = $(".active");

            if (output === true) {
                return true;
            } else {
                //prevent refresh
                e.preventDefault();
                $("#" + current.attr("id") + "-field").show();
                $("#back").show();
                $("#finish").show();
            }
        });
    });
    </script>

</head>

<body>
    <?php include "header.php"?>

    <div class="container-fluid my-4">

        <h3 class="text-center">Create Your Digital Visiting Card</h3>
        <h6>Enter your details and create your own in just three steps.</h6>
        <ul id="signup-step">
            <li id="personal" class="active">Build</li>
            <li id="password">Customize</li>
            <li id="contact">Choose Design</li>
        </ul>

        <?php
        if (isset($success)) {
            echo '<div>User record inserted successfully</div>';
        }

        $attributes = array('name' => 'frmRegistration', 'id' => 'signup-form');
        
        echo form_open($this->uri->uri_string(), $attributes);
        ?>

        <div id="personal-field">
            <label>First Name</label><span id="fname-error" class="signup-error"></span>
            <div><input type="text" name="fname" id="fname" class="demoInputBox" /></div>
            <label>Last Name</label><span id="lname-error" class="signup-error"></span>
            <div><input type="text" name="lname" id="name" class="demoInputBox" /></div>
            <label>Phone</label><span id="phone-error" class="signup-error"></span>
            <div><input type="text" name="phone" id="phone" class="demoInputBox" /></div>
            <label>Email</label><span id="email-error" class="signup-error"></span>
            <div><input type="text" name="email" id="email" class="demoInputBox" /></div><label>Enter
                Password</label><span id="password-error" class="signup-error"></span>
            <div><input type="password" name="password" id="password" class="demoInputBox" /></div>
        </div>

        <div id="password-field" style="display:none;">
            <div class="inner">
                <div class="ttl-block">
                    <h1>Your Dibiz should look just as good as you.</h1>
                    <!-- <div class="text-small"></div> -->
                </div>
                <div class="mdl-grid">
                    <div id="fb-card" class="mdl-cell mdl-cell--8-col gray-card">
                        <h5>To make this even easier, we can pull your Facebook Page or Profile images. To do so, We
                            need you to link your Facebook account with Dibiz.</h5>
                        <div class="action-wrapper">
                            <div class="actions">
                                <a class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored mdl-button-large"
                                    href="/users/auth/facebook" data-upgraded=",MaterialButton">
                                    <span id="fb-ico"><img src="/assets/registration/fb-ico.png" alt="Facebook"
                                            width="34" height="34"></span>Let's do it. Log in with facebook
                                </a> </div>
                            <div class="text-small">In the next step you need to give facebook permission to provide us
                                some basic profile information.</div>
                        </div>
                    </div>

                    <div class="mdl-cell mdl-cell--4-col gray-card">
                        <h5>Don't Have Facebook?<br>No Worries</h5>
                        <div class="action-wrapper">
                            <div class="actions">
                                <a class="mdl-button mdl-js-button mdl-button--raised mdl-button-large mdl-dark-gray"
                                    href="/en/select-design" data-upgraded=",MaterialButton">Continue without
                                    facebook</a>
                            </div>
                            <div class="text-small">Next, you will be asked to provide a featured image for your Dibiz.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- <div class="text-small go-back">
			</div> -->
            </div>
        </div>

        <div id="contact-field" style="display:none;">
            <label>Phone</label><span id="phone-error" class="signup-error"></span>
            <div><input type="text" name="phone" id="phone" class="demoInputBox" /></div>
            <label>Email</label><span id="email-error" class="signup-error"></span>
            <div><input type="text" name="email" id="email" class="demoInputBox" /></div>
            <label>Address</label><span id="address-error" class="signup-error"></span>
            <div><textarea name="address" id="address" class="demoInputBox" rows="5" cols="50"></textarea></div>
        </div>
        <div class="form-group my-2">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                <label class="form-check-label" for="invalidCheck">
                    Agree to terms and conditions
                </label>
                <div class="invalid-feedback">
                    You must agree before submitting.
                </div>
            </div>
        </div>
        <div>
            <input class="btnAction" type="button" name="back" id="back" value="Back" style="display:none;">
            <input class="btnAction" type="button" name="next" id="next" value="Next">
            <input class="btnAction" type="submit" name="finish" id="finish" value="Finish" style="display:none;">
        </div>
        <?php echo form_close(); ?>



    </div>

    <?php include "footer.php"?>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
</body>

</html>
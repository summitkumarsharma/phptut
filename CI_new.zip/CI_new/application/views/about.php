<!doctype html>
<html lang="en">

<head>
    <title>About:Digital Visiting Card</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link rel="stylesheet" href="<?= base_url()?>Assets/css/style.css">
</head>

<body>
    <?php include "Partials/header.php"?>

    <section class="container-fluid px-0">
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="https://source.unsplash.com/1600x500/?technology,digital" class="d-block w-100 img-fluid"
                        alt="ProductImage">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="py-4">
                <h2 class="text-center text-danger">About Us</h2>
            </div>
            <div class="accordion" id="accordionExample">
                <div class="card">
                    <div class="card-header" id="headingOne">
                        <h2 class="mb-0">
                            <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse"
                                data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp;About Product
                            </button>
                        </h2>
                    </div>

                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                        data-parent="#accordionExample">
                        <div class="card-body">
                            Digital visiting card is now a days important as digital screens and smart phones are a
                            trend
                            and provides modern way to share your contact and maximize your online networking. Digital
                            visiting
                            cards
                            offers smart communication in one click with unlimited sharing to your clients as paper
                            printed
                            cards are
                            boring, time consuming, need professionals to design because printing methods don't deliver
                            same
                            clarity. In
                            case of change in number you can automatically update, there's no need of a new set of
                            printing
                            cards and no
                            need to be carried along.
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header" id="headingTwo">
                        <h2 class="mb-0">
                            <button class="btn btn-link btn-block text-left collapsed" type="button"
                                data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false"
                                aria-controls="collapseTwo">
                                <i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp;Mobility at its finest
                            </button>
                        </h2>
                    </div>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                        <div class="card-body">
                            The shortest route to your customers is through their mobile phones. Utilize our share
                            options
                            and
                            take your brand viral by sharing your Branding Bazar Digital Contact Card with your clients
                            and
                            friends.
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header" id="headingThree">
                        <h2 class="mb-0">
                            <button class="btn btn-link btn-block text-left collapsed" type="button"
                                data-toggle="collapse" data-target="#collapseThree" aria-expanded="false"
                                aria-controls="collapseThree">
                                <i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp;New Opportunity
                            </button>
                        </h2>
                    </div>
                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                        data-parent="#accordionExample">
                        <div class="card-body">
                            Digital Business Card that is smart, elegant & affordable.
                            <li>Instant Informative</li>
                            <li>Generate more opportunity for online networking.</li>
                            <li>Update details any number of times.</li>
                            <li>Maximize your online presence.</li>
                            <li>Easy. Create within minutes</li>
                            <li>Impressive Rich Content</li>
                            <li>Share from anywhere & anytime</li>
                            <li>Add to contact</li>
                            <li>Save trees and contribute to the environment</li>


                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

    <?php include "Partials/footer.php"?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    <script>
    AOS.init({
        offset: 200,
        duration: 1000,
        easing: 'ease'

    });
    </script>
</body>

</html>
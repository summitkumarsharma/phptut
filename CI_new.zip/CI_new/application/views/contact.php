<!doctype html>
<html lang="en">

<head>
    <title>Contact:Digital Visiting Card</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url()?>Assets/css/style.css">
</head>

<body>
    <?php include "Partials/header.php"?>

    <section class="container-fluid px-0">
        <div class="container-fluid px-0">
            <img src="<?= base_url()?>Assets/img/contact-img/contact-bg.jpg" alt="" style="width:100%; height:60%;"
                class="d-block w-100 img-fluid">
        </div>

        <?php if($contact_msg = $this->session->flashdata('contact_msg')):$contact_class=$this->session->flashdata('contact_class') ?>
        <div class="alert <?=$contact_class?> alert-dismissible fade show" role="alert">
            <?= $contact_msg ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif;?>


        <div class="container my-4">
            <div class="row">
                <div class="col-lg-4 col-md-4 my-auto">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="text-center">Contact Us</h3>
                        </div>
                        <div class="card-body">
                            <p class="card-title"><i class="fa fa-home fa-fw" aria-hidden="true"></i>&nbsp;Shop No
                                138,1st
                                Floor,Balaji Tower,Khajuri Bazar,Indore M.P – 452001</p>
                            <p class="card-text"><i class="fa fa-phone-square" aria-hidden="true"></i>&nbsp;Mobile
                                No.-+91-9009883336.</p>

                        </div>
                        <div class="card-footer text-muted">
                            <p> <i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;brandingbazar@gmail.com</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-10 my-auto">
                    <p>Want to get in touch? Fill out the form below to send me a message and We will get back to you as
                        soon
                        as possible!</p>
                    <?php echo form_open('contact/addcontact');?>
                    <div class="form-row">
                        <div class="form-group col-md-8">
                            <label for="Name">Name:</label>
                            <?php echo form_input(['class'=>'form-control','id'=>'text','name'=>'name','placeholder'=>'Enter Your name','value'=>set_value('')]);?>
                        </div>
                        <div class="form-group col-md-4" style="margin-top:40px">
                            <?php echo form_error('name'); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-8">
                            <label for="email">Email Address:</label>
                            <?php echo form_input(['class'=>'form-control','id'=>'email','name'=>'email','placeholder'=>'Enter Email Address','value'=>set_value('')]);?>
                        </div>
                        <div class="form-group col-md-4" style="margin-top:40px">
                            <?php echo form_error('email'); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-8">
                            <label for="phone">Phone Number:</label>
                            <?php echo form_input(['class'=>'form-control','id'=>'phone','name'=>'phone','placeholder'=>'Enter Phone','value'=>set_value('')]);?>
                        </div>
                        <div class="form-group col-md-4" style="margin-top:40px">
                            <?php echo form_error('phone'); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-8">
                            <label for="lastname">Message:</label>
                            <?php echo form_textarea(['class'=>'form-control','id'=>'message','name'=>'message','placeholder'=>'Enter Message','value'=>set_value('')]);?>
                        </div>
                        <div class="form-group col-md-4" style="margin-top:40px">
                            <?php echo form_error('message'); ?>
                        </div>
                    </div>

                    <?php echo form_submit(['class'=>'btn btn-primary','type'=>'submit','value'=>'Send']);?>
                    <?php echo form_reset(['class'=>'btn btn-primary','type'=>'reset','value'=>'Reset']);?>

                </div>

                </form>
            </div>
        </div>
        </div>

    </section>




    <?php include "Partials/footer.php"?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
</body>

</html>
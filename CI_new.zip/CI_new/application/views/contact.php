<!doctype html>
<html lang="en">

<head>
    <title>Contact:Digital Visiting Card</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url()?>Assets/css/style.css">
</head>

<body>
    <?php include "Partials/header.php"?>

    <section class="container-fluid px-0">
        <div class="container-fluid px-0">
            <img src="<?= base_url()?>Assets/img/contact-img/contact-bg.jpg" alt="" style="width:100%; height:60%;"
                class="d-block w-100 img-fluid">
        </div>
        <div class="container my-4">
            <div class="row">
                <div class="col-lg-4 col-md-4 my-auto">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="text-center">Contact Us</h3>
                        </div>
                        <div class="card-body">
                            <p class="card-title"><i class="fa fa-home fa-fw" aria-hidden="true"></i>&nbsp;Shop No
                                138,1st
                                Floor,Balaji Tower,Khajuri Bazar,Indore M.P – 452001</p>
                            <p class="card-text"><i class="fa fa-phone-square" aria-hidden="true"></i>&nbsp;Mobile
                                No.-+91-9009883336.</p>

                        </div>
                        <div class="card-footer text-muted">
                            <p> <i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;brandingbazar@gmail.com</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-10 my-auto">
                    <p>Want to get in touch? Fill out the form below to send me a message and We will get back to you as
                        soon
                        as possible!</p>
                    <form name="sentMessage" id="contactForm" novalidate>
                        <div class="control-group">
                            <div class="form-group floating-label-form-group controls">
                                <label>Name</label>
                                <input type="text" class="form-control" placeholder="Name" id="name" required
                                    data-validation-required-message="Please enter your name.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="form-group floating-label-form-group controls">
                                <label>Email Address</label>
                                <input type="email" class="form-control" placeholder="Email Address" id="email" required
                                    data-validation-required-message="Please enter your email address.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>Phone Number</label>
                                <input type="tel" class="form-control" placeholder="Phone Number" id="phone" required
                                    data-validation-required-message="Please enter your phone number.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="form-group floating-label-form-group controls">
                                <label>Message</label>
                                <textarea rows="5" class="form-control" placeholder="Message" id="message" required
                                    data-validation-required-message="Please enter a message."></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <br>
                        <div id="success"></div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary" id="sendMessageButton">Send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </section>




    <?php include "Partials/footer.php"?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
</body>

</html>
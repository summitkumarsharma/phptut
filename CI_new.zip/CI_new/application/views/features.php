<?php include "header.php"?>

<section id="features" class="container my-4">
    <div class="row featurette d-flex justify-content-center align-items-center my-2">
        <div class="col-md-7">
            <h4 class="featurette-heading">Our Mission - To Meet Digital Business Card that is smart, elegant &
                affordable.<span class="text-muted">It will blow your mind.</span></h4>
            <p class="lead">Digital visiting card is now a days important as digital screens and smart phones are a
                trend and provides modern way to share your contact and maximize your online networking.Generate more
                opportunity for online networking..</p>
        </div>
        <div class="col-md-5">
            <img src="<?= base_url('Assets/img/feature-img/feature-1.jpg')?>" width="150" height="150"
                class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
        </div>
    </div>
    <div class="row featurette d-flex justify-content-center align-items-center my-2">
        <div class="col-md-7 order-md-2">
            <h4 class="featurette-heading">Our Vision -<span class="text-muted">Save trees and contribute
                    to the environment</span></h4>
            <p class="lead">Digital visiting cards offers smart communication in one click with unlimited sharing to
                your clients as paper printed cards are boring, time consuming, need professionals to design because
                printing methods don't deliver same clarity.</p>
        </div>
        <div class="col-md-5">
            <img src="<?= base_url('Assets/img/feature-img/feature-2.png')?>" width="150" height="150"
                class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
        </div>
    </div>
    <div class="row featurette d-flex justify-content-center align-items-center my-2">
        <div class="col-md-7">
            <h2 class="featurette-heading">Our Goal- <span class="text-muted">Mobility at its finest.</span></h2>
            <p class="lead">The shortest route to your customers is through their mobile phones. Utilize our share
                options and take your brand viral by sharing your Branding Bazar Digital Contact Card with your clients
                and friends.</p>
        </div>
        <div class="col-md-5">
            <img src="<?= base_url('Assets/img/feature-img/feature-3.jpeg')?>" width="150" height="150"
                class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
        </div>
    </div>

</section>





<?php include "footer.php"?>
<!doctype html>
<html lang="en">

<head>
    <title>Features:Digital Visiting Card</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url()?>Assets/css/style.css">
</head>

<body>
    <?php include "Partials/header.php"?>

    <section id="features" class="container my-4">
        <div class="row featurette d-flex justify-content-center align-items-center text-primary my-2">
            <h2>Our Product Features</h2>
        </div>
        <div class="row featurette d-flex justify-content-center align-items-center my-2">
            <div class="col-md-7">
                <h4 class="featurette-heading"><span class="text-muted">Meet Digital Business Card that is smart,
                        elegant &
                        affordable.</span></h4>
                <p class="lead">Digital visiting card is now a days important as digital screens and smart phones are a
                    trend and provides modern way to share your contact and maximize your online networking.Generate
                    more
                    opportunity for online networking..</p>
            </div>
            <div class="col-md-5">
                <img src="<?=base_url()?>Assets/img/feature-img/feature-1.jpg" width="100" height="100"
                    class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
            </div>
        </div>
        <div class="row featurette d-flex justify-content-center align-items-center my-2">
            <div class="col-md-7 order-md-2">
                <h4 class="featurette-heading"><span class="text-muted">Save trees and contribute
                        to the environment</span></h4>
                <p class="lead">Digital visiting cards offers smart communication in one click with unlimited sharing to
                    your clients as paper printed cards are boring, time consuming, need professionals to design because
                    printing methods don't deliver same clarity.</p>
            </div>
            <div class="col-md-5">
                <img src="<?=base_url()?>Assets/img/feature-img/feature-2.png" width="100" height="100"
                    class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
            </div>
        </div>
        <div class="row featurette d-flex justify-content-center align-items-center my-2">
            <div class="col-md-7">
                <h2 class="featurette-heading"><span class="text-muted">Mobility at its finest.</span></h2>
                <p class="lead">The shortest route to your customers is through their mobile phones. Utilize our share
                    options and take your brand viral by sharing your Branding Bazar Digital Contact Card with your
                    clients
                    and friends.</p>
            </div>
            <div class="col-md-5">
                <img src="<?=base_url()?>Assets/img/feature-img/feature-3.jpeg" width="100" height="100"
                    class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
            </div>
        </div>

    </section>

    <?php include "Partials/footer.php"?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
</body>

</html>
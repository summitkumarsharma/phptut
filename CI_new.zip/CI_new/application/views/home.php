<?php include "header.php"?>

<section id="home" class="container-fluid px-0">
    <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="https://source.unsplash.com/1600x500/?digital-buisness-card,ecard" class="d-block w-100"
                    alt="Slider_Image1">
                <div class="carousel-caption d-none d-md-block">
                    <h3>Inspire your clients... Digitally...</h3>
                    <p>Express yourself in ways never before possible with a business card. You can showcase
                        your work by uploading rich content such as photos, videos and custom links.</p>
                    <button class="btn btn-success my-2 my-sm-0" type="submit"><i class="fa fa-hand-o-right"
                            aria-hidden="true"></i>&nbsp;Get it Now,It's free</button>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://source.unsplash.com/1600x500/?phone-buisness,card" class="d-block w-100"
                    alt="Slider_Image2">
                <div class="carousel-caption d-none d-md-block">
                    <h3>Mobility at its finest</h3>
                    <p>Digital Business Card that is smart, elegant & affordable..</p><button
                        class="btn btn-success my-2 my-sm-0" type="submit"><i class="fa fa-hand-o-right"
                            aria-hidden="true"></i>&nbsp;Get it Now,It's free</button>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://source.unsplash.com/1600x500/?E-buisness,card" class="d-block w-100"
                    alt="Slider_Image3">
                <div class="carousel-caption d-none d-md-block">
                    <h3>Digital Business Card that is smart, elegant & affordable.</h3>
                    <p>Utilize our share options and take your brand viral by sharing your Branding Bazar
                        Digital Contact Card with your clients and friends..</p>
                    <button class="btn btn-success my-2 my-sm-0" type="submit"><i class="fa fa-hand-o-right"
                            aria-hidden="true"></i>&nbsp;Get it Now,It's free</button>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

</section>


<section id="how" class="container my-4 text-center text-light">
    <h2 class="text-primary">How it Works?</h2>
    <div class="row my-4">
        <div class="col-lg-4">
            <img src="<?= base_url('Assets/img/how_img/how-1.png')?>" width="50" height="50"
                class="card-img-top img-fluid mx-auto rounded-circle" alt="card_image">
            <h6> Step1 - Create your DVC (Image) in 3 simple steps and you've got your very own digital business
                card.
            </h6>
            <p class="my-4"><a class=" btn btn-secondary" href="#" role="button">Click here to begin »</a></p>
        </div>
        <div class="col-lg-4">
            <img src="<?= base_url('Assets/img/how_img/how-2.png')?>" width="50" height="50"
                class="card-img-top img-fluid mx-auto rounded-circle" alt="card_image">
            <h6> Step2 - Save to your device (Image).it's accessible from practically anywhere and can easily be
                sharedwith others.</h6>

            <p class="my-4"><a class="btn btn-secondary" href="#" role="button">Learn More »</a></p>
        </div>
        <div class="col-lg-4">
            <img src="<?= base_url('Assets/img/how_img/how-3.png')?>" width="50" height="50"
                class="card-img-top img-fluid mx-auto rounded-circle" alt="card_image">
            <h6> Step3 - Share - Share – Share (Image):You will then be able to choose from any of the sharing
                methods
                available (SMS, WhatsApp, Email and Facebook).
            </h6>

            <p class="my-4"><a class=" btn btn-secondary" href="#" role="button">Explore More »</a></p>
        </div>
    </div>
</section>
<hr>
<section id="features" class="container my-2 text-light">
    <div class="row featurette d-flex justify-content-center align-items-center text-primary my-2">
        <h2>Our Product Features</h2>
    </div>
    <div class="row featurette d-flex justify-content-center align-items-center my-2">
        <div class="col-lg-7 col-md-7 col-sm-7">
            <h4 class="featurette-heading">Digital Business Card that is smart, elegant & affordable.<span
                    class="text-muted">It will blow your mind.</span></h4>
            <p class="lead">Digital visiting card is now a days important as digital screens and smart phones are a
                trend and provides modern way to share your contact and maximize your online networking.Generate more
                opportunity for online networking..</p>
        </div>
        <div class="col-lg-5 col-md-5 col-sm-5">
            <img src="<?= base_url('Assets/img/feature-img/feature-1.jpg')?>" width="150" height="150"
                class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
        </div>
    </div>
    <div class="row featurette d-flex justify-content-center align-items-center my-2">
        <div class="col-lg-7 col-md-7 col-sm-7 order-md-2">
            <h4 class="featurette-heading">Our Vision and Mission-<span class="text-muted">Save trees and contribute
                    to the environment</span></h4>
            <p class="lead">Digital visiting cards offers smart communication in one click with unlimited sharing to
                your clients as paper printed cards are boring, time consuming, need professionals to design because
                printing methods don't deliver same clarity.</p>
        </div>
        <div class="col-lg-5 col-md-5 col-sm-5">
            <img src="<?= base_url('Assets/img/feature-img/feature-2.png')?>" width="150" height="150"
                class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
        </div>
    </div>
    <div class="row featurette d-flex justify-content-center align-items-center my-2">
        <div class="col-lg-7 col-md-7 col-sm-7">
            <h2 class="featurette-heading">Our Goal- <span class="text-muted">Mobility at its finest.</span></h2>
            <p class="lead">The shortest route to your customers is through their mobile phones. Utilize our share
                options and take your brand viral by sharing your Branding Bazar Digital Contact Card with your clients
                and friends.</p>
        </div>
        <div class="col-lg-5 col-md-5 col-sm-5">
            <img src="<?= base_url('Assets/img/feature-img/feature-3.jpeg')?>" width="150" height="150"
                class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
        </div>
    </div>

</section>
<section id="client-section" class="container-fluid bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h3>Trusted by leading companies</h3>
            </div>
        </div>
        <div class="row clients-inner">
            <div class="col-md-2">
                <img src="" alt="Remax">
            </div>
            <div class="col-md-2">
                <img src="" alt="TD Bank">
            </div>
            <div class="col-md-2" id="toyota">
                <img src="" alt="Toyota">
            </div>
            <div class="col-md-2" id="lancome">
                <img src="" alt="Lancome">
            </div>
            <div class="col-md-2">
                <img src="" alt="Ford">
            </div>
            <div class="col-md-2" id="jeep">
                <img src="" alt="Jeep">
            </div>
        </div>
    </div>
</section>
<section id="comm-section" class="container-fluid bg-info text-light">
    <div class="container text-center py-2">
        <div class="row">
            <div class="col-md-12 text-center">
                <h4>Join our community and take your Digital buisness Cards to the next level</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="fadeInDown delay3 animated dp3"><span>199,866 </span></div>
                <div class=""><span><span class="translation_missing"
                            title="translation missing: en.index.new.section_one.customers">Customers</span></span>
                </div>
            </div>
            <div class="col-md-4">
                <div class="fadeInDown delay3 animated dp3"><span>14,438,808</span></div>
                <div class=""><span>Card Views</span></div>
            </div>
            <div class="col-md-4 trees">
                <div class="fadeInDown delay3 animated dp3"><span>Millions</span></div>
                <div class=""><span>OF TREES TO BE SAVED</span></div>
            </div>
        </div>
    </div>
</section>

<?php include "footer.php"?>
<!doctype html>
<html lang="en">

<head>
    <title>Welcome to Digital Visiting Card</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link rel="stylesheet" href="<?= base_url()?>Assets/css/style.css">
</head>

<body>
    <?php include "Partials/header.php"?>
    <div class="container-fluid px-0">
        <section id="home" class="container-fluid px-0">
            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="https://source.unsplash.com/1600x700/?digital,phone" class="d-block w-100"
                            alt="Slider_Image1">
                        <div class="carousel-caption d-none d-md-block">
                            <h3>Inspire your clients... Digitally...</h3>
                            <p>Express yourself in ways never before possible with a business card. You can showcase
                                your work by uploading rich content such as photos, videos and custom links.</p>
                            <a href="signup" class="btn btn-success my-2 my-sm-0" type="submit"><i
                                    class="fa fa-hand-o-right" aria-hidden="true"></i>&nbsp;Get it Now,It's free</a>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="https://source.unsplash.com/1600x700/?paperlesswork,office" class="d-block w-100"
                            alt="Slider_Image2">
                        <div class="carousel-caption d-none d-md-block">
                            <h3>Mobility at its finest</h3>
                            <p>Digital Business Card that is smart, elegant & affordable..</p>
                            <a href="signup" class="btn btn-success my-2 my-sm-0" type="submit"><i
                                    class="fa fa-hand-o-right" aria-hidden="true"></i>&nbsp;Get it Now,It's free</a>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="https://source.unsplash.com/1600x700/?visitingcard,digital" class="d-block w-100"
                            alt="Slider_Image3">
                        <div class="carousel-caption d-none d-md-block">
                            <h3>Digital Business Card that is smart, elegant & affordable.</h3>
                            <p>Utilize our share options and take your brand viral by sharing your Branding Bazar
                                Digital Contact Card with your clients and friends..</p>
                            <a href="signup" class="btn btn-success my-2 my-sm-0" type="submit"><i
                                    class="fa fa-hand-o-right" aria-hidden="true"></i>&nbsp;Get it Now,It's free</a>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>

        </section>

        <section id="About" class="container-fluid text-dark pb-4 pt-2" style="background:aqua">
            <h2 class="text-center text-danger" data-aos="flip-left">About</h2>
            <div class="container">
                <div class="row d-flex justify-content-center align-items-center">
                    <div class="col-md-6" data-aos="fade-right">
                        <div class="row justify-content-center align-items-center">
                            <h5 class="">Printed Visiting card are boring</h5>
                        </div>
                        <div class="row justify-content-center align-items-center">
                            <img src="<?= base_url()?>Assets/img/about-img/about-img-1.jpg"
                                class="card-img-top img-fluid mx-auto rounded-pill how--part1" alt="card_image" ;
                                style="width:400px; height:300px;">
                        </div>
                    </div>
                    <div class="col-md-6" data-aos="fade-left">
                        <div class="row justify-content-center align-items-center">
                            <h5 class="">Go Paperless, Go Green and Go Digital</h5>

                        </div>
                        <div class="row justify-content-center align-items-center">
                            <img src="<?= base_url()?>Assets/img/about-img/about-img-2.jpg"
                                class="card-img-top img-fluid mx-auto rounded-pill how--part1" alt="card_image" ;
                                style="width:400px; height:300px;">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="how" class="container my-4 text-center text-dark">
            <h2 class="text-primary text-danger" data-aos="flip-left">How it Works?</h2>
            <div class="row my-4">
                <div class="col-md-4" data-aos="fade-left">
                    <img src="<?= base_url()?>Assets/img/how_img/how-6.jpg"
                        class="card-img-top img-fluid mx-auto rounded-circle how--part1" alt="card_image" ;
                        style="width:200px; height:200px;">
                    <h4><span class="badge badge-warning">Step 1</span></h4>
                    <h6 class="my-4">Create your DVC (Image) in 3 simple steps and you've got your very own digital
                        business
                        card.
                    </h6>
                    <p class="my-4"><a class=" btn btn-primary" href="signup" role="button">Click here to begin »</a>
                    </p>
                </div>
                <div class="col-md-4" data-aos="fade-up">
                    <img src="<?=base_url()?>Assets/img/how_img/how-7.jpg"
                        class="card-img-top img-fluid mx-auto rounded-circle" alt="card_image"
                        style="width:200px; height:200px;">
                    <h4><span class="badge badge-warning">Step 2</span></h4>
                    <h6 class="my-4">Save to your device (Image).it's accessible from practically anywhere and can
                        easily be
                        shared with others.</h6>

                    <p class="my-4"><a class="btn btn-primary" href="how" role="button">Learn More »</a></p>
                </div>
                <div class="col-md-4" data-aos="fade-right">
                    <img src="<?=base_url()?>Assets/img/how_img/how-5.jpg"
                        class="card-img-top img-fluid mx-auto rounded-circle" alt="card_image"
                        style="width:200px; height:200px;">
                    <h4><span class="badge badge-warning">Step 3</span></h4>
                    <h6 class="my-4">Share - Share – Share (Image):You will then be able to choose from any of the
                        sharing
                        methods
                        available (SMS, WhatsApp, Email and Facebook).
                    </h6>

                    <p class="my-4"><a class=" btn btn-primary" href="pricing" role="button">Explore More »</a></p>
                </div>
            </div>
        </section>
        <hr>
        <section id="features" class="container-fluid my-4">
            <div class="row featurette d-flex justify-content-center align-items-center text-primary my-2"
                data-aos="flip-left">
                <h2 class="text-danger">Our Product Features</h2>
            </div>
            <div class="row featurette d-flex justify-content-center align-items-center my-2" data-aos="fade-left">
                <div class="col-md-7">
                    <h4 class="featurette-heading"><span class="text-muted">Meet Digital Business Card that is smart,
                            elegant &
                            affordable.</span></h4>
                    <p class="lead">Digital visiting card is now a days important as digital screens and smart phones
                        are a
                        trend and provides modern way to share your contact and maximize your online networking.Generate
                        more
                        opportunity for online networking..</p>
                </div>
                <div class="col-md-5">
                    <img src="<?=base_url()?>Assets/img/feature-img/feature-2.png" style="width:400px; height:300px"
                        class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
                </div>
            </div>
            <div class="row featurette d-flex justify-content-center align-items-center my-2" data-aos="fade-right">
                <div class="col-md-7 order-md-2">
                    <h4 class="featurette-heading"><span class="text-muted">Save trees and contribute
                            to the environment</span></h4>
                    <p class="lead">Digital visiting cards offers smart communication in one click with unlimited
                        sharing to
                        your clients as paper printed cards are boring, time consuming, need professionals to design
                        because
                        printing methods don't deliver same clarity.</p>
                </div>
                <div class="col-md-5">
                    <img src="<?=base_url()?>Assets/img/feature-img/feature-1.jpg" style="width:400px; height:300px"
                        class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
                </div>
            </div>
            <div class="row featurette d-flex justify-content-center align-items-center my-2" data-aos="fade-left">
                <div class="col-md-7">
                    <h2 class="featurette-heading"><span class="text-muted">Mobility at its finest.</span></h2>
                    <p class="lead">The shortest route to your customers is through their mobile phones. Utilize our
                        share
                        options and take your brand viral by sharing your Branding Bazar Digital Contact Card with your
                        clients
                        and friends.</p>
                </div>
                <div class="col-md-5">
                    <img src="<?=base_url()?>Assets/img/feature-img/feature-3.jpg" style="width:400px; height:300px"
                        class="card-img-top img-fluid mx-auto rounded-pill" alt="card_image">
                </div>
            </div>

        </section>
        <section id="client-section" class="container-fluid bg-light">
            <div class="container d-flex flex-column py-4 justify-content-center align-items-center" data-aos="zoom-in">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h3 class="text-danger">Trusted by Most Leading companies</h3>
                    </div>
                </div>
                <div class="row text-center">
                    <div class="col-md-2 mr-4 ml-4">
                        <img src="<?=base_url()?>Assets/img/client-img/logo1.png" style="width:150px; height:150px;"
                            class="card-img-top img-fluid mx-auto rounded-pill" alt="logo_image">
                    </div>
                    <div class="col-md-2 mr-4">
                        <img src="<?=base_url()?>Assets/img/client-img/logo2.png" style="width:150px; height:150px;"
                            class="card-img-top img-fluid mx-auto rounded-pill" alt="logo_image">
                    </div>
                    <div class="col-md-2 mr-4">
                        <img src="<?=base_url()?>Assets/img/client-img/logo3.png" style="width:150px; height:150px;"
                            class="card-img-top img-fluid mx-auto rounded-pill" alt="logo_image">
                    </div>
                    <div class="col-md-2 mr-4">
                        <img src="<?=base_url()?>Assets/img/client-img/logo4.png" style="width:150px; height:150px;"
                            class="card-img-top img-fluid mx-auto rounded-pill" alt="logo_image">
                    </div>
                    <div class="col-md-2 mr-4">
                        <img src="<?=base_url()?>Assets/img/client-img/logo5.png" style="width:150px; height:150px;"
                            class="card-img-top img-fluid mx-auto rounded-pill" alt="logo_image">
                    </div>

                </div>
            </div>
        </section>
        <section id="community-section" class="container-fluid bg-info">
            <div class="container text-center py-2" data-aos="zoom-in">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h4 class="text-danger">Join our community and take your Digital buisness Cards to the next
                            level
                        </h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="fadeInDown delay3 animated dp3"><span>199,866 </span></div>
                        <div class=""><span><span class="translation_missing"
                                    title="translation missing: en.index.new.section_one.customers">Customers</span></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="fadeInDown delay3 animated dp3"><span>14,438,808</span></div>
                        <div class=""><span>Card Views</span></div>
                    </div>
                    <div class="col-md-4 trees">
                        <div class="fadeInDown delay3 animated dp3"><span>Millions</span></div>
                        <div class=""><span>OF TREES TO BE SAVED</span></div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <?php include "Partials/footer.php"?>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
    AOS.init({
        offset: 150,
        duration: 1000,
        easing: 'ease'

    });
    </script>
</body>

</html>
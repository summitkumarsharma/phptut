<!doctype html>
<html lang="en">

<head>
    <title>How it works:Digital Visiting Card</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url()?>Assets/css/style.css">
</head>

<body>
    <?php include "Partials/header.php"?>

    <section class="container-fluid px-0">

        <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item justify-content-center active">
                    <div class="carousel-caption d-none d-md-block">
                        <h1 class="text-center bg-dark ">How it Works?</h1>
                    </div>
                    <img src="https://source.unsplash.com/1600x400/?digitalvisiting,card" class="d-block w-100"
                        alt="ProductImage">
                </div>
            </div>
        </div>
        <div class="container my-4">
            <div class="accordion" id="accordionExample">
                <div class="card">
                    <div class="card-header" id="headingOne">
                        <h2 class="mb-0">
                            <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse"
                                data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp;Step1 Create your DVC (Image)
                                in
                                3 simple steps and you've got your very own digital business card:

                            </button>
                        </h2>
                    </div>

                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                        data-parent="#accordionExample">
                        <div class="card text-center">
                            <div class="card-header">
                                Create your account
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Click here and fill out the form in order to signup to your
                                    Branding
                                    Bazar DVC account.</h5>
                                <p class="card-text">With supporting text below as a natural lead-in to additional
                                    content.
                                </p>
                                <a href="#" class="btn btn-primary">Create Now <i class="fa fa-sign-in"
                                        aria-hidden="true"></i></a>
                            </div>

                        </div>
                        <div class="card text-center">
                            <div class="card-header">
                                Choose a Design
                            </div>
                            <div class="card-body">
                                <p class="card-text">Choose between our selections of beautiful designs. All our
                                    templates
                                    are mobile and user friendly, look great and are easy to customize. Not sure what to
                                    choose? No worries! You can easily switch designs at any time.
                                </p>

                            </div>
                        </div>
                        <div class="card text-center">
                            <div class="card-header">
                                Add your Content
                            </div>
                            <div class="card-body">
                                <p class="card-text">DVC is all about rich content. Besides your contact details and
                                    social
                                    networks, consider adding a gallery of photos, Youtube videos and custom links so
                                    your
                                    customers get a rich experience of you!.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header" id="headingTwo">
                        <h2 class="mb-0">
                            <button class="btn btn-link btn-block text-left collapsed" type="button"
                                data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false"
                                aria-controls="collapseTwo">
                                <i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp; Step 2- Save to your device
                                (Image)
                            </button>
                        </h2>
                    </div>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                        <div class="card-body">
                            <p>Once you're done setting up your Branding bazaar DVC – you will receive a text message
                                with
                                the link to your card. We encourage our users to save the card to the home screen of
                                their
                                mobile device – that way it's accessible from practically anywhere and can easily be
                                shared
                                with others.</p>
                            <p>Here are instructions on how to save to the home screen for iOS and Android:</p>

                            <li>iPhone/iOS users:<a href="https://www.dibiz.com/en/save-card/iphone"> click here </a>
                            </li>
                            <li>Android users:<a href="https://www.dibiz.com/en/save-card/android"> click here </a></li>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header" id="headingThree">
                        <h2 class="mb-0">
                            <button class="btn btn-link btn-block text-left collapsed" type="button"
                                data-toggle="collapse" data-target="#collapseThree" aria-expanded="false"
                                aria-controls="collapseThree">
                                <i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp; Step 3-Share - Share – Share
                                (Image)
                            </button>
                        </h2>
                    </div>
                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                        data-parent="#accordionExample">
                        <div class="card-body">
                            Whenever you want to share your DVC with someone, just open your DVC and click on the
                            "Share"
                            button on your card.
                            You will then be able to choose from any of the sharing methods available (SMS, WhatsApp,
                            Email
                            and Facebook).
                            You can also copy the link to your DVC and share it just like any other web page.

                        </div>
                    </div>
                </div>
            </div>

        </div>

    </section>




    <?php include "Partials/footer.php"?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
</body>

</html>
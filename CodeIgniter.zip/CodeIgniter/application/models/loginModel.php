<?php

class loginModel extends CI_Model{
    
    public function isvalidate($username,$password){
        
        $sql= $this->db->where(['uname'=>$username,'pass'=>$password])->get('my_users');
        $result = $sql->num_rows();
        if($result){
            return $sql->row()->id;
        }
        else{
            return false;
        }
    }
    public function showarticlelist(){
      
        $id = $this->session->userdata('id');
        $sql= $this->db->select(array('id','article_title','article_desc','tstamp'))->from('articles')->where(['user_id'=>$id])->get();
        return $sql->result() ;
    }
    public function showblogarticlelist(){
      
        $sql= $this->db->select()->from('articles')->get();
        return $sql->result() ;
    }
    public function add_article($array){
      
       
        return $this->db->insert('articles',$array);
       
     }
     public function del_article($id){
      
       
        return $this->db->delete('articles',['id'=>$id]);
       
     }
     public function add_user($array){
      
       
        return $this->db->insert('my_users',$array);
       
     
     }
}
<?php include "header.php"?>

<div class="container my-4 shadow-lg p-3 mb-5 bg-white rounded">

    <h3 class="text-center wow pulse" data-wow-iteration="infinite" data-wow-duration="500ms">Welcome to My Blog</h3>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="https://source.unsplash.com/1600x500/?Blog,coding" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="https://source.unsplash.com/1600x500/?tech,blog" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="https://source.unsplash.com/1600x500/?programming,blog" class="d-block w-100" alt="...">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <div class="container my-3">
        <h3 class="my-4 text-center wow bounce" data-wow-iteration="infinite" data-wow-duration="800ms">Browse Our
            Latest Blog</h3>

        <?php if(count($articles)):?>
        <?php  foreach($articles as $art ): ?>
        <div class="card text-center">
            <div class="card-header">
                <?php echo $art->article_title;?>
            </div>
            <div class="card-body">
                <p class="card-text"><?php echo substr($art->article_desc,0,200);?></p>
                <a href="#" class="btn btn-sm btn-primary">Read More</a>
            </div>
            <div class="card-footer text-muted">
                <p>Posted by<a href="#"> Administrator </a> on <?php echo $art->tstamp;?></p>
            </div>
        </div>
        <hr>
        <?php endforeach; ?>
        <?php endif; ?>

    </div>

</div>


<?php include "footer.php"?>